# Contributing to CodeIgniter Coding Standard

CodeIgniter Coding Standard is a community driven project and accepts contributions of
code and documentation from the community.

If you'd like to contribute, please read the [Contributing to CodeIgniter](https://github.com/codeigniter4/CodeIgniter4/blob/develop/contributing/README.md)
guide in the [main repository](https://github.com/codeigniter4/CodeIgniter4).

If you are going to contribute to this repository, please report bugs or send PRs
to this repository instead of the main repository.
